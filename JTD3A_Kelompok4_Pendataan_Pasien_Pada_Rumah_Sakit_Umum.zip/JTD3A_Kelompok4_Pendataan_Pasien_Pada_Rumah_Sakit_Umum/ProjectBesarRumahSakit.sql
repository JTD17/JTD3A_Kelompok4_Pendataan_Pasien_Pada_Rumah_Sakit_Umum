-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: rumah_sakit
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `checkout`
--

DROP TABLE IF EXISTS `checkout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `checkout` (
  `No_CM` varchar(100) NOT NULL,
  `Nama_Pasien` varchar(100) NOT NULL,
  `Kode_Dokter` varchar(100) NOT NULL,
  `Kode_Ruang` varchar(100) NOT NULL,
  PRIMARY KEY (`No_CM`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `checkout`
--

LOCK TABLES `checkout` WRITE;
/*!40000 ALTER TABLE `checkout` DISABLE KEYS */;
INSERT INTO `checkout` VALUES ('CMP-01','Ariska Maya','D3','R-01'),('CMP-02','Bima Sena','D2','R-07'),('CMP-03','Ciara Ramadhani','D4','R-06'),('CMP-04','Della Rosita','D8','R-03'),('CMP-05','Eka Sulistya','D5','R-05'),('CMP-06','Farid Januar','D1','R-02'),('CMP-07','Gilang Surya P','D6','R-09'),('CMP-08','Heru Firmansyah','D4','R-13'),('CMP-09','Ining Orlin','D5','R-04'),('CMP-10','Joko Sunaryo','D3','R-11');
/*!40000 ALTER TABLE `checkout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dokter`
--

DROP TABLE IF EXISTS `dokter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dokter` (
  `Kode_Dokter` varchar(100) NOT NULL,
  `Nama_Dokter` varchar(100) NOT NULL,
  `Alamat` varchar(100) NOT NULL,
  `Kode_Spesialis` varchar(100) NOT NULL,
  `Spesialis_Dokter` varchar(100) NOT NULL,
  PRIMARY KEY (`Kode_Dokter`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dokter`
--

LOCK TABLES `dokter` WRITE;
/*!40000 ALTER TABLE `dokter` DISABLE KEYS */;
INSERT INTO `dokter` VALUES ('D1','dr. Diaris, Sp. A','Malang','S1','Spesialis Anak'),('D2','dr. Besut Daryanto, Sp. B, Sp.U','Malang','S2','Spesialis Bedah'),('D3','dr. Debby Shintiya Dewi, Sp. M','Malang','S3','Spesialis Mata'),('D4','dr. Muhayati Kusuma Wardani','Malang','S4','Spesialis General Check-Up'),('D5','dr. Rahajeng, Sp.OG','Malang','S5','Spesialis Kandungan'),('D6','Dr. Dr. Pudji Rahaju, Sp. T.H.T.K.L','Malang','S6','Spesialis THT'),('D7','Dr. dr. Susanthy Dj, Sp.P','Malang','S7','Spesialis Paru'),('D8','dr. Frilya Rachma Putri, Sp.KJ','Malang','S8','Spesialis Jiwa'),('D9','dr. Endang Inderawati','Malang','S9','Spesialis Koplementer');
/*!40000 ALTER TABLE `dokter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `obat`
--

DROP TABLE IF EXISTS `obat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `obat` (
  `Kode_Obat` varchar(100) NOT NULL,
  `Nama_Obat` varchar(1000) NOT NULL,
  `Jenis_Obat` varchar(100) NOT NULL,
  PRIMARY KEY (`Kode_Obat`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `obat`
--

LOCK TABLES `obat` WRITE;
/*!40000 ALTER TABLE `obat` DISABLE KEYS */;
INSERT INTO `obat` VALUES ('Jantung1','Acepress, Captopril, Dexacap, Etapril, Farmoten, Forten, Otoryl, Prix, Tensicap, Tensobon, Vapril, Farmoten, Tensicap, Tensobon','Captopril'),('Jantung2','Cardace, Decapril, Triatec','Ramipril'),('Jantung3','Odace, Tensinop','Lisinopril'),('Jantung4','Bioprexum','Perindopril'),('Jantung5','Tenaten','Enalapril'),('Jantung6','Tarka','Trandolapril'),('Jantung7','Lamda, Kendaron, Cordarone, Rexodrone, Amiodarone HCL, Tiaryt, Cortifib, Cordarone','Amiodarone'),('Jantung8','Amovask, Quentin, Amlodipine Besilate, Amlodipine Besylate, Concor AM, Normetec, Simvask, Zenovask, Comdipin, Norvask','Amlodipine'),('Kandungan1','Progeston, Alyrenol, Nobor, Obstanon, Pregtenol, Premaston, Gravynon, Prestrenol, Preboran, Preabor, Pregnolin, Pregnabion','Allylestrenol'),('Paru1','Aminophylline, Phaminov, Erphafillin','Aminofilin');
/*!40000 ALTER TABLE `obat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pasien`
--

DROP TABLE IF EXISTS `pasien`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pasien` (
  `No_CM` varchar(100) NOT NULL,
  `Nama_Pasien` varchar(100) NOT NULL,
  `Poli_Tujuan` varchar(100) NOT NULL,
  `Asal_Rujukan` varchar(100) NOT NULL,
  `Diagnosa` varchar(100) NOT NULL,
  `Rekam_Medis` varchar(100) NOT NULL,
  `Jenis_Kelamin` varchar(100) NOT NULL,
  `Tgl_Lahir` varchar(100) NOT NULL,
  `Status` varchar(100) NOT NULL,
  PRIMARY KEY (`No_CM`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pasien`
--

LOCK TABLES `pasien` WRITE;
/*!40000 ALTER TABLE `pasien` DISABLE KEYS */;
INSERT INTO `pasien` VALUES ('CMP-01','Ariska Maya','Klinik Mata','Rumah Sakit Lavalette','Pendarahan Sub-Konjungtiva','Milik Dokter','P','Malang,10-3-1994','Rawat Jalan'),('CMP-02','Bima Sena','Klinik Bedah','RSB Pembantu Malang','Usus Buntu','Milik Dokter','L','Malang,29-1-1965','Rawat Inap'),('CMP-03','Ciara Ramadhani','Klinik General Check-Up','RS Panti Waluya','Medical Check-Up','Milik Dokter','P','Malang,11-1-1994','Rawat Jalan'),('CMP-04','Della Rosita','Klinik Jiwa','RSU Griya Mekar Melati','Konsultasi','Milik Dokter','P','Malang,17-11-1998','Rawat Jalan'),('CMP-05','Eka Sulistya','Klinik Kandungan','Rumah Sakit Lavalette','Keluhan Kandungan','Milik Dokter','P','Malang,2-7-1991','Rawat Jalan'),('CMP-06','Farid Januar','Klinik Anak','PSB Pembantu Malang','Maramus','Milik Dokter','L','Malang,20-5-2003','Rawat Inap'),('CMP-07','Gilang Surya P','Klinik THT','RS Panti Waluya','Sinusitis','Milik Dokter','L','Malang,19-3-1998','Rawat Inap'),('CMP-08','Heru Firmansyah','Klinik General Check_Up','RSU Bhakti Bunda','Medical Check-Up','Milik Dokter','L','Malang,27-5-1995','Rawat Jalan'),('CMP-09','Ining Orlin','Klinik Kandungan','Rumah Sakit Lavalette','Persalinan','Milik Dokter','P','Malang,1-1-1989','Rawat Inap'),('CMP-10','Joko Sunaryo','Klinik Mata','RSU Bhakti Bunda','Tukak(Ulkus)Kornea','Milik Dokter','L','Malang,24-9-1994','Rawat Jalan');
/*!40000 ALTER TABLE `pasien` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `perawat`
--

DROP TABLE IF EXISTS `perawat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `perawat` (
  `Kode_Perawat` varchar(100) NOT NULL,
  `Nama_Perawat` varchar(100) NOT NULL,
  `Hasil_Perawatan` varchar(100) NOT NULL,
  PRIMARY KEY (`Kode_Perawat`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `perawat`
--

LOCK TABLES `perawat` WRITE;
/*!40000 ALTER TABLE `perawat` DISABLE KEYS */;
INSERT INTO `perawat` VALUES ('Perawat-01','Arsala F.I, S.Kep','Milik Perawat'),('Perawat-02','Ayuni Tria, Amd.Kep','Milik Perawat'),('Perawat-03','Mutya Cahyani, Amd.Kep','Milik Perawat'),('Perawat-04','Desilia Nur, S.Kep','Milik Perawat'),('Perawat-05','Rais Saputra, S.Kep','Milik Perawat'),('Perawat-06','Irfan Juni, Amd.Kep','Milik Perawat'),('Perawat-07','Afriza Lestari, S.Kep','Milik Perawat'),('Perawat-08','Pramasella Octa, Amd.Kep','Milik Perawat'),('Perawat-09','Susi Rahmawati, S.Kep','Milik Perawat'),('Perawat-10','Amanda Citra, Amd.Kep','Milik Perawat'),('Perawat-11','Aminudin Rois, S.Kep','Milik Perawat'),('Perawat-12','Galih Rahayu, Amd.Kep','Milik Perawat'),('Perawat-13','Eki Soka, Amd.Kep','Milik Perawat'),('Perawat-14','Ayu Dayanti, S.Kep','Milik Perawat'),('Perawat-15','Berlin Riskia, S.Kep','Milik Perawat');
/*!40000 ALTER TABLE `perawat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `petugas`
--

DROP TABLE IF EXISTS `petugas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `petugas` (
  `Kode_Petugas` varchar(100) NOT NULL,
  `Nama_Petugas` varchar(100) NOT NULL,
  `Alamat_Petugas` varchar(100) NOT NULL,
  `jam_jaga` varchar(50) NOT NULL,
  PRIMARY KEY (`Kode_Petugas`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `petugas`
--

LOCK TABLES `petugas` WRITE;
/*!40000 ALTER TABLE `petugas` DISABLE KEYS */;
INSERT INTO `petugas` VALUES ('Petugas-01','Hadi Riyanto','Malang','07.00-13.00'),('Petugas-02','Anas Bakri','Malang','07.00-13.00'),('Petugas-03','Rengga Andita','Malang','07.00-13.00'),('Petugas-04','Roni Pujo','Malang','13.00-19.00'),('Petugas-05','Malik Fais','Malang','13.00-19.00'),('Petugas-06','Sani Nurdianto','Malang','13.00-19.00'),('Petugas-07','Rohman S','Malang','19.00-01.00'),('Petugas-08','Ardi Pratama','Malang','19.00-01.00'),('Petugas-09','Hendro Sasono','Malang','19.00-01.00'),('Petugas-10','Rizal P','Malang','01.00-07.00'),('Petugas-11','Mukti','Malang','01.00-07.00'),('Petugas-12','Riskon','Malang','01.00-07.00');
/*!40000 ALTER TABLE `petugas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `poli_tujuan`
--

DROP TABLE IF EXISTS `poli_tujuan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `poli_tujuan` (
  `Kode_Poli_Tujuan` varchar(100) NOT NULL,
  `Poli_Tujuan` varchar(100) NOT NULL,
  PRIMARY KEY (`Kode_Poli_Tujuan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `poli_tujuan`
--

LOCK TABLES `poli_tujuan` WRITE;
/*!40000 ALTER TABLE `poli_tujuan` DISABLE KEYS */;
INSERT INTO `poli_tujuan` VALUES ('1','Klinik Anak'),('2','Klinik Bedah'),('3','Klinik Mata'),('4','Klinik General Checkup'),('5','Klinik Kebidanan & Kandungan'),('6','Klinik THT'),('7','Klinik Paru'),('8','Klinik Jiwa'),('9','Klinik Komplementer');
/*!40000 ALTER TABLE `poli_tujuan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rawat`
--

DROP TABLE IF EXISTS `rawat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rawat` (
  `Kode_Rawat` int NOT NULL AUTO_INCREMENT,
  `No_CM` varchar(100) NOT NULL,
  `Kode_Perawat` varchar(100) NOT NULL,
  PRIMARY KEY (`Kode_Rawat`),
  KEY `Kode_Perawat` (`Kode_Perawat`),
  CONSTRAINT `rawat_ibfk_1` FOREIGN KEY (`Kode_Perawat`) REFERENCES `perawat` (`Kode_Perawat`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rawat`
--

LOCK TABLES `rawat` WRITE;
/*!40000 ALTER TABLE `rawat` DISABLE KEYS */;
INSERT INTO `rawat` VALUES (1,'CMP-01','Perawat-03'),(2,'CMP-02','Perawat-07'),(3,'CMP-03','Perawat-08'),(4,'CMP-04','Perawat-01'),(5,'CMP-05','Perawat-04'),(6,'CMP-06','Perawat-09'),(7,'CMP-07','Perawat-02'),(8,'CMP-08','Perawat-11'),(9,'CMP-09','Perawat-12'),(10,'CMP-10','Perawat-13');
/*!40000 ALTER TABLE `rawat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ruang`
--

DROP TABLE IF EXISTS `ruang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ruang` (
  `Kode_Ruang` varchar(100) NOT NULL,
  `Nama_Ruang` varchar(100) NOT NULL,
  `Nama_Gedung` varchar(100) NOT NULL,
  PRIMARY KEY (`Kode_Ruang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ruang`
--

LOCK TABLES `ruang` WRITE;
/*!40000 ALTER TABLE `ruang` DISABLE KEYS */;
INSERT INTO `ruang` VALUES ('R-01','Ruang Wijaya Kusuma','Graha Puspa Husada'),('R-02','Ruang Mawar','Graha Puspa Husada'),('R-03','Ruang Melati','Graha Puspa Husada'),('R-04','Ruang Dahlia','Graha Puspa Husada'),('R-05','Ruang Bugenville','Graha Puspa Husada'),('R-06','Ruang Raflesia','Graha Puspa Husada'),('R-07','Ruang Tulip','Graha Puspa Husada'),('R-08','Ruang Lili','Graha Puspa Husada'),('R-09','Ruang Dahlia','Graha Puspa Husada'),('R-10','Ruang Seruni','Graha Puspa Husada'),('R-11','Ruang Asoka','Graha Puspa Husada'),('R-12','Ruang Azalea','Graha Puspa Husada'),('R-13','Ruang Adenium','Graha Puspa Husada');
/*!40000 ALTER TABLE `ruang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shift_jaga`
--

DROP TABLE IF EXISTS `shift_jaga`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shift_jaga` (
  `Kode_Shift` int NOT NULL AUTO_INCREMENT,
  `Tanggal` varchar(100) NOT NULL,
  `Shift` varchar(100) NOT NULL,
  `Kode_Petugas` varchar(100) NOT NULL,
  PRIMARY KEY (`Kode_Shift`),
  KEY `Kode_Petugas` (`Kode_Petugas`),
  CONSTRAINT `shift_jaga_ibfk_1` FOREIGN KEY (`Kode_Petugas`) REFERENCES `petugas` (`Kode_Petugas`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shift_jaga`
--

LOCK TABLES `shift_jaga` WRITE;
/*!40000 ALTER TABLE `shift_jaga` DISABLE KEYS */;
INSERT INTO `shift_jaga` VALUES (1,'24/4/2020','07.00-13.00','Petugas-01'),(2,'24/4/2020','07.00-13.00','Petugas-02'),(3,'24/4/2020','07.00-13.00','Petugas-03'),(4,'24/4/2020','13.00-19.00','Petugas-04'),(5,'24/4/2020','13.00-19.00','Petugas-05'),(6,'24/4/2020','13.00-19.00','Petugas-06'),(7,'24/4/2020','19.00-01.00','Petugas-07'),(8,'24/4/2020','19.00-01.00','Petugas-08'),(9,'24/4/2020','19.00-01.00','Petugas-09'),(10,'24/4/2020','01.00-07.00','Petugas-10'),(11,'24/4/2020','01.00-07.00','Petugas-11'),(12,'24/4/2020','02.00-07.00','Petugas-12');
/*!40000 ALTER TABLE `shift_jaga` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `spesialisasi_dokter`
--

DROP TABLE IF EXISTS `spesialisasi_dokter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `spesialisasi_dokter` (
  `Kode_Spesialisasi` varchar(100) NOT NULL,
  `Spesialisasi_Dokter` varchar(100) NOT NULL,
  PRIMARY KEY (`Kode_Spesialisasi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `spesialisasi_dokter`
--

LOCK TABLES `spesialisasi_dokter` WRITE;
/*!40000 ALTER TABLE `spesialisasi_dokter` DISABLE KEYS */;
INSERT INTO `spesialisasi_dokter` VALUES ('Spesialis 1','Spesialis Anak'),('Spesialis 2','Spesialis Bedah'),('Spesialis 3','Spesialis Mata'),('Spesialis 4','Spesialis General Chech-Up'),('Spesialis 5','Spesialis Kandungan'),('Spesialis 6','Spesialis THT'),('Spesialis 7','Spesialis Paru'),('Spesialis 8','Spesialis Jiwa'),('Spesialis 9','Spesialis Komplementer');
/*!40000 ALTER TABLE `spesialisasi_dokter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaksi`
--

DROP TABLE IF EXISTS `transaksi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaksi` (
  `No_CM` varchar(100) NOT NULL,
  `Tgl_Bayar` varchar(100) NOT NULL,
  `Jumlah` varchar(100) NOT NULL,
  PRIMARY KEY (`No_CM`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaksi`
--

LOCK TABLES `transaksi` WRITE;
/*!40000 ALTER TABLE `transaksi` DISABLE KEYS */;
INSERT INTO `transaksi` VALUES ('CMP-01','27/4/2020','Rp 875.000,-'),('CMP-02','27/4/2020','Rp 1.700.000,-'),('CMP-03','24/4/2020','Rp 1.250.000,-'),('CMP-04','25/4/2020','Rp 250.000,-'),('CMP-05','25/4/2020','Rp 700.000,-'),('CMP-06','26/4/2020','Rp 900.000,-'),('CMP-07','23/4/2020','Rp 1.800.000,-'),('CMP-08','28/4/2020','Rp 1.250.000,-'),('CMP-09','22/4/2020','Rp 4.500.000,-'),('CMP-10','28/4/2020','Rp 2.500.000,-');
/*!40000 ALTER TABLE `transaksi` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-11 16:46:27
