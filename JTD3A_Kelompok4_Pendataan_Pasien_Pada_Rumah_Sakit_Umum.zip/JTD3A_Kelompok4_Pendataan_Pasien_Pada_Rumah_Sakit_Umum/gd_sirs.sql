-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: localhost:3307
-- Generation Time: Jul 01, 2020 at 11:52 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `gd_sirs`
--

-- --------------------------------------------------------

--
-- Table structure for table `dokter`
--

CREATE TABLE IF NOT EXISTS `dokter` (
`kd_dokter` int(11) NOT NULL,
  `kd_poli` int(11) NOT NULL,
  `tgl_kunjungan` int(12) NOT NULL,
  `kd_user` int(11) NOT NULL,
  `nm_dokter` varchar(300) NOT NULL,
  `sip` enum('pagi','siang','malam','') NOT NULL,
  `tmpat_lhr` varchar(300) NOT NULL,
  `no_tlp` varchar(14) NOT NULL,
  `alamat` varchar(300) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dokter`
--

INSERT INTO `dokter` (`kd_dokter`, `kd_poli`, `tgl_kunjungan`, `kd_user`, `nm_dokter`, `sip`, `tmpat_lhr`, `no_tlp`, `alamat`) VALUES
(9, 1, 1593534759, 11, 'dr.Soeta ,Sp A', 'pagi', '', '088812742', 'Perum.Graha Tlogomas '),
(10, 1, 1593534942, 11, 'dr.Diaris, Sp.A', 'siang', '', '08818902342', 'Blimbing GG.XI Malang'),
(11, 1, 1593535172, 11, 'Dr. Dr. Pudji Rahaju, Sp. KJ', 'malam', '', '08872245682', 'Mergosono GG.X Malang'),
(12, 6, 1593535549, 11, 'Dr.Dr. Pudji Rahaju Sp. T.H.T.K.L', '', '', '087771764882', 'Perum.Puncak Tidar B/12'),
(13, 8, 1593535810, 11, 'Dr.dr. Susanthy Dj, Sp.P', '', '', '08991284212', 'Perum.Tlogowaru A/9'),
(14, 1, 1593535898, 11, 'dr. Debby S D, Sp.M', '', '', '08812938127', 'Perum.Araya Z/19'),
(15, 1, 1593542228, 11, 'KONG', '', '', '0811172739', 'KONTRAKAN');

-- --------------------------------------------------------

--
-- Table structure for table `kunjungan`
--

CREATE TABLE IF NOT EXISTS `kunjungan` (
  `tgl_kunjungan` date NOT NULL,
  `no_pasien` int(11) NOT NULL,
  `kd_poli` int(11) NOT NULL,
  `jam_kunjungan` time NOT NULL,
`kd_kunjungan` int(12) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kunjungan`
--

INSERT INTO `kunjungan` (`tgl_kunjungan`, `no_pasien`, `kd_poli`, `jam_kunjungan`, `kd_kunjungan`) VALUES
('2020-06-30', 27, 5, '07:28:00', 11),
('2020-06-30', 24, 2, '07:30:00', 12),
('2020-06-30', 25, 8, '07:35:00', 13),
('2020-06-30', 29, 7, '07:36:00', 14),
('2020-06-30', 24, 1, '07:38:00', 15),
('2020-06-30', 31, 4, '07:38:00', 16),
('2020-06-30', 30, 6, '07:39:00', 17),
('2020-06-30', 26, 8, '07:39:00', 18);

-- --------------------------------------------------------

--
-- Table structure for table `laboratorium`
--

CREATE TABLE IF NOT EXISTS `laboratorium` (
`kd_lab` int(11) NOT NULL,
  `no_rm` int(11) NOT NULL,
  `hasil_lab` varchar(300) NOT NULL,
  `ket` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `laboratorium`
--

INSERT INTO `laboratorium` (`kd_lab`, `no_rm`, `hasil_lab`, `ket`) VALUES
(4, 6, 'Berhasil', 'Berhasil Uji Laborat'),
(5, 6, 'Gagal', 'Kekurangan Peralatan'),
(6, 6, 'Berhasil', 'Berhasil melakukan uji coba.'),
(7, 5, 'Berhasil Uji Coba', 'Pengujian kadar gula darah pada pasien'),
(8, 11, 'Berhasil', 'Rekam Jantung'),
(9, 11, 'Gagal', 'Kekurangan Peralatan Medis\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
`kd_user` int(11) NOT NULL,
  `username` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `nama` varchar(20) NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`kd_user`, `username`, `password`, `nama`, `alamat`) VALUES
(11, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'RENDRA ANDIKA RAMAHA', 'MLG'),
(12, 'admin2', 'c84258e9c39059a89ab77d846ddab909', 'INDAHSARI', 'MLG');

-- --------------------------------------------------------

--
-- Table structure for table `obat`
--

CREATE TABLE IF NOT EXISTS `obat` (
`kd_obat` int(11) NOT NULL,
  `nm_obat` varchar(300) NOT NULL,
  `jml_obat` int(11) NOT NULL,
  `ukuran` int(11) NOT NULL,
  `harga` int(25) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `obat`
--

INSERT INTO `obat` (`kd_obat`, `nm_obat`, `jml_obat`, `ukuran`, `harga`) VALUES
(1, 'Paracetamol', 10, 10, 10000),
(4, 'Tenaten', 20, 5, 200000),
(5, 'Komik', 200, 1, 1000),
(6, 'Tarka', 50, 1, 15000),
(7, 'Bioprexum', 30, 1, 40000),
(8, 'Odece', 25, 2, 35000),
(9, 'Aminophylline', 60, 1, 13000),
(10, 'Progeston', 70, 1, 11000),
(11, 'Cardace', 55, 2, 30000);

-- --------------------------------------------------------

--
-- Table structure for table `pasien`
--

CREATE TABLE IF NOT EXISTS `pasien` (
`no_pasien` int(11) NOT NULL,
  `nm_pasien` varchar(300) NOT NULL,
  `j_kel` varchar(100) NOT NULL,
  `agama` varchar(100) NOT NULL,
  `alamat` varchar(300) NOT NULL,
  `tgl_lhr` date NOT NULL,
  `usia` int(3) NOT NULL,
  `no_tlp` varchar(14) NOT NULL,
  `nm_kk` varchar(300) NOT NULL,
  `hub_kel` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pasien`
--

INSERT INTO `pasien` (`no_pasien`, `nm_pasien`, `j_kel`, `agama`, `alamat`, `tgl_lhr`, `usia`, `no_tlp`, `nm_kk`, `hub_kel`) VALUES
(24, 'Mahaen', 'Pria', 'Islam', 'Malang', '1998-12-05', 21, '2147483647', 'Sulton', 'Anak Kandung'),
(25, 'Ariska Maya', 'Pria', 'Islam', 'Malang', '1999-09-01', 20, '2147483647', 'YOJI', 'Anak Kandung'),
(26, 'Bima Sena ', 'Pria', 'Islam', 'Malang', '2000-01-15', 19, '2147483647', 'YUDA', 'Lainnya'),
(27, 'Ciara Ramadhani', 'Wanita', 'Islam', 'Malang', '2001-05-21', 18, '2147483647', 'gomblo', 'Lainnya'),
(28, 'Della Rosita', 'Wanita', 'Islam', 'Malang', '0000-00-00', 18, '2147483647', 'Nana', 'Anak Kandung'),
(29, 'Farid Januar ', 'Pria', 'Islam', 'Malang', '1999-09-14', 20, '2147483647', 'Jujun', 'Lainnya'),
(30, 'Herru Firmansyah', 'Pria', 'Islam', 'Malang', '1999-06-11', 21, '822129412', 'Doni', 'Anak Kandung'),
(31, 'Surya', 'Pria', 'Islam', 'Malang', '2002-04-02', 17, '877182934', 'Tutan', 'Lainnya'),
(32, 'REZA', 'Pria', 'Islam', 'Malang', '0000-00-00', 17, 'Sakit', 'JULIANTO', 'Anak Kandung');

-- --------------------------------------------------------

--
-- Table structure for table `poliklinik`
--

CREATE TABLE IF NOT EXISTS `poliklinik` (
`kd_poli` int(11) NOT NULL,
  `nm_poli` varchar(300) NOT NULL,
  `lantai` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `poliklinik`
--

INSERT INTO `poliklinik` (`kd_poli`, `nm_poli`, `lantai`) VALUES
(1, 'Poli Perut', 4),
(2, 'Poli Jantung', 1),
(4, 'Poli Tulang', 3),
(5, 'Poli Beda Saraf', 1),
(6, 'Poli THT', 2),
(7, 'Poli Mata', 2),
(8, 'Poli Paru', 1);

-- --------------------------------------------------------

--
-- Table structure for table `rekam_medis`
--

CREATE TABLE IF NOT EXISTS `rekam_medis` (
`no_rm` int(11) NOT NULL,
  `kd_tindakan` int(11) NOT NULL,
  `kd_obat` int(11) NOT NULL,
  `kd_user` int(11) NOT NULL,
  `nama_pasien` varchar(20) NOT NULL,
  `diagnosa` varchar(300) NOT NULL,
  `resep` varchar(300) NOT NULL,
  `keluhan` varchar(300) NOT NULL,
  `tgl_pemeriksaan` int(12) NOT NULL,
  `ket` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rekam_medis`
--

INSERT INTO `rekam_medis` (`no_rm`, `kd_tindakan`, `kd_obat`, `kd_user`, `nama_pasien`, `diagnosa`, `resep`, `keluhan`, `tgl_pemeriksaan`, `ket`) VALUES
(11, 5, 1, 11, 'Ariska Maya', 'gejala', 'Cardace 1 tablet', 'Gatal gatal disertai panas', 1593572059, 'Baru pertama kali'),
(12, 5, 1, 11, 'REZA', 'gejala', 'Progeston 2 tablet', 'Sakit di dada', 1593572074, 'Baru Pertama Kali'),
(13, 5, 1, 11, 'Mahaen', 'gejala', 'Aminophylline', 'Sakit Hati', 1593572085, 'Udah Sering'),
(14, 5, 1, 11, 'Herru Firmansyah', 'gejala', 'Odece', 'Telinga Budeg', 1593572096, 'Baru Pertama Kali'),
(15, 5, 1, 11, 'Farid Januar ', 'gejala', 'Bioprexum 1 tablet', 'Sakit Mata ', 1593572109, 'Agak Buram'),
(16, 5, 1, 11, 'Della Rosita', 'gejala', 'Tarka 1 tablet', 'Sakit Tenggorokan', 1593572121, 'Radang '),
(17, 5, 1, 11, 'Ciara Ramadhani', 'gejala', 'Bioprexum 1 tablet', 'Diare', 1593572162, 'Mual');

-- --------------------------------------------------------

--
-- Table structure for table `tindakan`
--

CREATE TABLE IF NOT EXISTS `tindakan` (
`kd_tindakan` int(11) NOT NULL,
  `nm_tindakan` varchar(300) NOT NULL,
  `ket` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tindakan`
--

INSERT INTO `tindakan` (`kd_tindakan`, `nm_tindakan`, `ket`) VALUES
(5, 'Rawat Inap', 'Di Rawat di Rumah Sakit'),
(7, 'Rawat Inap', 'UPT Puskesmas 1'),
(8, 'Rawat Jalan', 'Rawat Jalan dengan minum obat teratur'),
(9, 'Rawat Jalan', 'Dirumah aja'),
(10, 'Rawat Jalan', 'Karantina 14 hari'),
(11, 'Rawat Inap', 'Di Rumah Sakit'),
(12, 'Rawat Jalan ', 'Banyakin Minum Vitamin C');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dokter`
--
ALTER TABLE `dokter`
 ADD PRIMARY KEY (`kd_dokter`);

--
-- Indexes for table `kunjungan`
--
ALTER TABLE `kunjungan`
 ADD PRIMARY KEY (`kd_kunjungan`);

--
-- Indexes for table `laboratorium`
--
ALTER TABLE `laboratorium`
 ADD PRIMARY KEY (`kd_lab`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
 ADD PRIMARY KEY (`kd_user`);

--
-- Indexes for table `obat`
--
ALTER TABLE `obat`
 ADD PRIMARY KEY (`kd_obat`);

--
-- Indexes for table `pasien`
--
ALTER TABLE `pasien`
 ADD PRIMARY KEY (`no_pasien`);

--
-- Indexes for table `poliklinik`
--
ALTER TABLE `poliklinik`
 ADD PRIMARY KEY (`kd_poli`);

--
-- Indexes for table `rekam_medis`
--
ALTER TABLE `rekam_medis`
 ADD PRIMARY KEY (`no_rm`);

--
-- Indexes for table `tindakan`
--
ALTER TABLE `tindakan`
 ADD PRIMARY KEY (`kd_tindakan`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dokter`
--
ALTER TABLE `dokter`
MODIFY `kd_dokter` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `kunjungan`
--
ALTER TABLE `kunjungan`
MODIFY `kd_kunjungan` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `laboratorium`
--
ALTER TABLE `laboratorium`
MODIFY `kd_lab` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
MODIFY `kd_user` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `obat`
--
ALTER TABLE `obat`
MODIFY `kd_obat` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `pasien`
--
ALTER TABLE `pasien`
MODIFY `no_pasien` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `poliklinik`
--
ALTER TABLE `poliklinik`
MODIFY `kd_poli` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `rekam_medis`
--
ALTER TABLE `rekam_medis`
MODIFY `no_rm` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `tindakan`
--
ALTER TABLE `tindakan`
MODIFY `kd_tindakan` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
